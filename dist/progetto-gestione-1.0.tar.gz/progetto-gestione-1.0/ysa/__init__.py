"""
Sentiment analysis and indexing package for YouTube videos and comments
"""