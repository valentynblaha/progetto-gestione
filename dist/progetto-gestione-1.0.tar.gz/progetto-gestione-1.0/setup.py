from setuptools import setup

setup(
    name='progetto-gestione',
    authors=['valentyn','jawad'],
    version='1.0',
    packages=['ysa'],
)